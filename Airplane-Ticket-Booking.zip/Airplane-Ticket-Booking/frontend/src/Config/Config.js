export const BACKENDURL = "https://avbsbackend.onrender.com";
// export const BACKENDURL = "http://localhost:5000";
